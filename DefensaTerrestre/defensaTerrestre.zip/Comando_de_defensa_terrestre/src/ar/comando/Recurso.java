package ar.comando;

import java.util.HashSet;
import java.util.Objects;

public abstract class Recurso {
	private static Integer nuevoId=1;
	private Integer idRecurso;
	private String nombre;
	private Double costoBase;
	private HashSet<EfectoEspecial> efectos;

	public Recurso(String nombre,Double costoBase) {
		this.idRecurso =nuevoId;
		nuevoId++;
		this.nombre = nombre;
		this.costoBase = costoBase;
		this.efectos = new HashSet<EfectoEspecial>();
	}
	public Double mayorMultiplicadorDeDanio() {
		Double mayor = 0.;
		for (EfectoEspecial ee : efectos) {
			if (ee.getMultiplicador()>mayor) {
				mayor = ee.getMultiplicador();
			}
		}
		return mayor;
	}
	public abstract Double costoDeProduccion();
	public abstract Double eficiencia();
	
	public static void resetearIdIncremetal() {
		nuevoId = 1;
	}
	public Integer getIdRecurso() {
		return idRecurso;
	}

	public void setIdRecurso(Integer idRecurso) {
		this.idRecurso = idRecurso;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Recurso other = (Recurso) obj;
		return Objects.equals(nombre, other.nombre);
	}

	public void agregarEfecto(EfectoEspecial efecto) {
		this.efectos.add(efecto);
	}

	public Integer cantidadDeEfectos() {
		return this.efectos.size();
	}
	public Double getCostoBase() {
		return costoBase;
	}
	

}
