package ar.comando;

public interface IRastreable {
	Boolean esRastreablePorElEnemigo();
}
