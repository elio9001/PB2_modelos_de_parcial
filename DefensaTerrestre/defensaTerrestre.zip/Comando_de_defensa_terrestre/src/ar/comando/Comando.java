package ar.comando;

import java.util.HashSet;

public class Comando {
	private HashSet<Recurso> recusos;
	public Comando() {
		recusos = new HashSet<Recurso>();
	}
	public void registrarRecurso(Recurso recurso) {
		this.recusos.add(recurso);
	}
	public Integer cantidadDeRecusosRegistrados() {
		return this.recusos.size();
	}
	public void agregarUnEfectoAUnRecurso(Integer idRecurso, EfectoEspecial efecto) {
		Recurso recursoEncontrado = buscarRecurso(idRecurso);
		if (recursoEncontrado!=null) {
			recursoEncontrado.agregarEfecto(efecto);
		}
		
	}
	private Recurso buscarRecurso(Integer idRecurso) {
		for (Recurso recurso : this.recusos) {
			if (recurso.getIdRecurso().equals(idRecurso)) {
				return recurso;
			}
		}
		return null;
	}
	public Integer cantidadDeEfectosDeUnRecurso(Integer idRecurso) {
		Recurso recursoEnRecurso = buscarRecurso(idRecurso);
		if (recursoEnRecurso!=null) {
			return recursoEnRecurso.cantidadDeEfectos();
		}
		return null;
	}
	public Double mayorMultiplicadorDeDanioDeUnRecurso(Integer idRecurso) {
		Recurso recursoEncontrado = buscarRecurso(idRecurso);
		if (recursoEncontrado!=null) {
			return recursoEncontrado.mayorMultiplicadorDeDanio();
		}
		return null;
	}
	public Double eficienciaDeUnRecurso(Integer idRecurso) {
		Recurso recursoEncontrado = buscarRecurso(idRecurso);
		if (recursoEncontrado!=null) {
			return recursoEncontrado.eficiencia();
		}
		return null;
	}
	public Double eficienciaTotalDeLosRecursos() {
		Double eficienciaTotal = 0.;
		for (Recurso recurso : recusos) {
			eficienciaTotal += recurso.eficiencia();
		}
		return eficienciaTotal;
	}
	public Double costoDeProduccionTotalDeLosRecursos() {
		Double costoProduccionTotal = 0.;
		for (Recurso recurso : recusos) {
			costoProduccionTotal += recurso.costoDeProduccion();
		}
		return costoProduccionTotal;
	}
	public HashSet<Recurso> obtenerRecursosNoRastreables() {
		HashSet<Recurso> recursosNoRastreables = new HashSet<Recurso>();
		for (Recurso recurso : recusos) {
			if (recurso instanceof IRastreable) {
				if (!((IRastreable) recurso).esRastreablePorElEnemigo()) {
					recursosNoRastreables.add(recurso);
				}
			}
			if (recurso instanceof Arma) {
				recursosNoRastreables.add(recurso);
			}
		}
		return recursosNoRastreables;
		
	}
	public Double porcentajeDeRecursosRastreables() {
		Integer cantidadDeRecursosRastreables = cantidadDeRecusosRegistrados() - obtenerRecursosNoRastreables().size();
		Double porcentaje = (cantidadDeRecursosRastreables*100.) / cantidadDeRecusosRegistrados()*1.;
		return porcentaje;
	}

}
