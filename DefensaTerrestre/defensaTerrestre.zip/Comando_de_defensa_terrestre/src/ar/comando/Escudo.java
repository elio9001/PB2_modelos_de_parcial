package ar.comando;

public class Escudo extends Recurso implements IRastreable{
	private final Integer sigiloMax = 100;
	private final Integer sigiloMin=0;
	private final Integer proteccionMax=10;
	private final Integer proteccionMin=0;
	private Integer nivelDeSigilo;
	private Integer nivelDeProteccion;

	public Escudo(String nombre, Double costoBase,Integer nivelDeSigilo, Integer nivelDeProteccion) {
		super(nombre, costoBase);
		this.nivelDeSigilo = nivelDeSigilo;
		this.nivelDeProteccion = nivelDeProteccion;
	}

	@Override
	public Double costoDeProduccion() {
		Double costoCalculado = super.getCostoBase() + super.getCostoBase() * (nivelDeProteccion/10.0);
		return costoCalculado;
	}

	@Override
	public Double eficiencia() {
		Double eficienciaCalculada = (nivelDeProteccion *100 )/costoDeProduccion();
		return eficienciaCalculada;
	}

	@Override
	public Boolean esRastreablePorElEnemigo() {
		if (nivelDeSigilo>=50) {
			return false;
		}
		return true;
	}

	
	
}
