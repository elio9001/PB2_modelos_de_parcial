package ar.comando;

import java.util.Objects;

public class EfectoEspecial {
	private String nombreEfecto;
	private Double multiplicadorDeDanio;
	private String alienAfectado;

	public EfectoEspecial(String nombre, Double multiplicador, String alienAfectado) {
		this.nombreEfecto = nombre;
		this.multiplicadorDeDanio = multiplicador;
		this.alienAfectado = alienAfectado;
	}

	public EfectoEspecial(TiposDeEfectos tipo) {
		this.nombreEfecto = tipo.name();
		this.multiplicadorDeDanio = tipo.getMultiplicador();
		this.alienAfectado = tipo.getAlienAfectado();
	}

	@Override
	public int hashCode() {
		return Objects.hash(nombreEfecto);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EfectoEspecial other = (EfectoEspecial) obj;
		return Objects.equals(nombreEfecto, other.nombreEfecto);
	}

	public Double getMultiplicador() {
		return this.multiplicadorDeDanio;
	}

}
