package ar.comando;

public class Arma extends Recurso {

	private TipoMunicion tipoMunicion;
	private Double factorMunicion;
	private Double alcance;

	public Arma(String nombre, Double costoBase, TipoMunicion tipo, Double factorMunicion,Double alcance) {
		super(nombre, costoBase);
		this.tipoMunicion = tipo;
		this.factorMunicion = factorMunicion;
		this.alcance = alcance;
	}

	@Override
	public Double costoDeProduccion() {
		return super.getCostoBase() * factorMunicion;
	}

	@Override
	public Double eficiencia() {
		return alcance / costoDeProduccion();
	}

}
