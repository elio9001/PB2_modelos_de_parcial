package ar.comando;

public enum TipoMunicion {
	LASER(1.0),PROYECTIL(1.3),PLASMA(1.8);

	private Double factorMunicion;

	TipoMunicion(Double factorMunicion) {
		this.factorMunicion = factorMunicion;
	}
}
