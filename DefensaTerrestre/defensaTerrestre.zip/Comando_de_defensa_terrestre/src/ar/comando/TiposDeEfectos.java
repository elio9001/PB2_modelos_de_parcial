package ar.comando;

public enum TiposDeEfectos {
	CONGELAMIENTO_ETEREO(1.2,"Etereos","Arma"),
	PROYECTIL_PERFORANTE(1.7,"Ciberneticos","Arma"),
	EXPLOSION_DE_PLASMA(2.0,"Reptilianos","Arma, Bomba"),
	ESCUDO_DE_IONES(0.8,"Reptilianos","Escudo"),
	DEBILITAMIENTO(1.3,"Humanoides","Arma, Escudo"),
	RADIACION_GAMA(2.5,"Insectoides","Bomba");
	
	private Double multiplicador;
	private String alienAfectado;
	private String recursoAplicable;
	TiposDeEfectos(Double multiplicador, String alienAfectado, String recursoAplicable) {
		this.multiplicador=multiplicador;
		this.alienAfectado = alienAfectado;
		this.recursoAplicable = recursoAplicable;
	}
	public Double getMultiplicador() {
		return multiplicador;
	}
	public String getAlienAfectado() {
		return alienAfectado;
	}
	public String getRecursoAplicable() {
		return recursoAplicable;
	}
	
}
