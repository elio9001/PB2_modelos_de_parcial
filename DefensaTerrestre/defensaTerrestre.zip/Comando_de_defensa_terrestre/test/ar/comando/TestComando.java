package ar.comando;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestComando {

	@Test
	public void dadoQueExisteUnComandoNoSePuedanRegistrarDosRecursoConElMismoNombre() {
		Recurso.resetearIdIncremetal();
		
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 1000.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 10;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);
		comando.registrarRecurso(new Escudo("escudo1", costoBase, nivelSigilo, nivelProteccion));

		Integer cantidadObtenida = comando.cantidadDeRecusosRegistrados();
		Integer cantidadEsperada = 1;
		assertEquals(cantidadEsperada, cantidadObtenida);
	}

	@Test
	public void dadoQueExisteUnComandoNoSePuedanRegistrarDosEfectosEspecialesConElMismoNombre() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 1000.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 10;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);

		EfectoEspecial efecto1 = new EfectoEspecial(TiposDeEfectos.ESCUDO_DE_IONES);
		EfectoEspecial efecto2 = new EfectoEspecial(TiposDeEfectos.ESCUDO_DE_IONES);

		comando.agregarUnEfectoAUnRecurso(1, efecto1);
		comando.agregarUnEfectoAUnRecurso(1, efecto2);
		Integer cantidadObtenida = comando.cantidadDeEfectosDeUnRecurso(1);
		Integer cantidadEsperada = 1;

		assertEquals(cantidadEsperada, cantidadObtenida);
	}

	@Test
	public void dadoQueExisteUnRecursoArmaSePuedaAsignarUnEfectoEspecial() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "arma1";
		Double costoBase = 1000.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 10;
		Arma arma1 = new Arma(nombre, costoBase, TipoMunicion.LASER, 1.0, 20.);

		comando.registrarRecurso(arma1);

		EfectoEspecial efecto1 = new EfectoEspecial(TiposDeEfectos.CONGELAMIENTO_ETEREO);
		comando.agregarUnEfectoAUnRecurso(1, efecto1);

		Integer cantidadObtenida = comando.cantidadDeEfectosDeUnRecurso(1);
		Integer cantidadEsperada = 1;
	}

	@Test
	public void dadoQueExisteUnRecursoEscudoSePuedaAsignarMultiplesEfectosEspeciales() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 1000.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 10;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);

		EfectoEspecial efecto1 = new EfectoEspecial(TiposDeEfectos.ESCUDO_DE_IONES);
		EfectoEspecial efecto2 = new EfectoEspecial(TiposDeEfectos.DEBILITAMIENTO);

		comando.agregarUnEfectoAUnRecurso(1, efecto1);
		comando.agregarUnEfectoAUnRecurso(1, efecto2);
		Integer cantidadObtenida = comando.cantidadDeEfectosDeUnRecurso(1);
		Integer cantidadEsperada = 2;
	}

	@Test
	public void dadoUnRecursoEscudoConMultiplesEfectosSePuedaObtenerElMayorMultiplicadoDeDanio() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 1000.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 10;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);

		EfectoEspecial efecto1 = new EfectoEspecial(TiposDeEfectos.ESCUDO_DE_IONES);
		EfectoEspecial efecto2 = new EfectoEspecial(TiposDeEfectos.DEBILITAMIENTO);

		comando.agregarUnEfectoAUnRecurso(1, efecto1);
		comando.agregarUnEfectoAUnRecurso(1, efecto2);

		Double mayorMultiplicadorObtenido = comando.mayorMultiplicadorDeDanioDeUnRecurso(1);
		Double multiplicadorEsperado = 1.3;
		assertEquals(multiplicadorEsperado, mayorMultiplicadorObtenido);
	}

	@Test
	public void dadoQueExisteUnComandoSePuedaCalcularLaEficienciaDeUnEscudo() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();
		
		String nombre = "escudo1";
		Double costoBase = 800.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 1;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);
		//Integer idEscudo1 = escudo1.nuevoId-1;
		comando.registrarRecurso(escudo1);
		Double eficienciaObtenida = comando.eficienciaDeUnRecurso(1);
		Double eficienciaEsperada = 0.11;

		assertEquals(eficienciaEsperada, eficienciaObtenida, 0.01);
	}

	@Test
	public void dadoQueExisteUnComandoSePuedaCalcularLaEficienciaTotalDeLosRecursosRegistrados() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 800.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 1;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);
		comando.registrarRecurso(new Escudo("escudo2", costoBase, nivelSigilo, nivelProteccion));

		Double eficienciaTotalObtenida = comando.eficienciaTotalDeLosRecursos();
		Double eficienciaTotalEsperada = 0.11 * 2;

		assertEquals(eficienciaTotalEsperada, eficienciaTotalObtenida, 0.01);
	}

	@Test
	public void dadoQueExisteUnComandoConVariosRecursosSePuedaCalcularElCostoTotalDeProducción() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 800.;
		Integer nivelSigilo = 20;
		Integer nivelProteccion = 1;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);
		comando.registrarRecurso(new Escudo("escudo2", costoBase, nivelSigilo, nivelProteccion));

		Double produccionTotalObtenida = comando.costoDeProduccionTotalDeLosRecursos();
		Double produccionTotalEsperada = 880.0 * 2;

		assertEquals(produccionTotalEsperada, produccionTotalObtenida);
	}

	@Test
	public void dadoUnComandoSePuedaObtenerLosRecursosQueNoSonRastreablePorLosEnemigos() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 800.;
		Integer nivelSigilo = 50;
		Integer nivelProteccion = 1;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);
		comando.registrarRecurso(new Escudo("escudo2", costoBase, 20, nivelProteccion));
		
		Integer cantidadEsperadaDeRecursos = 1;
		assertEquals(cantidadEsperadaDeRecursos, comando.obtenerRecursosNoRastreables().size(), 0.01);
	}

	@Test
	public void dadoUnComandoSePuedaObtenerElPorcentajeDeRecursosQueSonRastreablePorLosEnemigos() {
		Recurso.resetearIdIncremetal();
		Comando comando = new Comando();

		String nombre = "escudo1";
		Double costoBase = 800.;
		Integer nivelSigilo = 50;
		Integer nivelProteccion = 1;
		Escudo escudo1 = new Escudo(nombre, costoBase, nivelSigilo, nivelProteccion);

		comando.registrarRecurso(escudo1);
		comando.registrarRecurso(new Escudo("escudo2", costoBase, 20, nivelProteccion));
		
		Double porcentajeObtenido = comando.porcentajeDeRecursosRastreables();
		Double porcentajeEsperado = 50.;
		assertEquals(porcentajeEsperado, porcentajeObtenido);
	}

}
