package ar.supermercado;

import java.util.ArrayList;

public abstract class Ticket {
	private String codTicket;
	private ArrayList<Producto> productos;
	public Ticket(String codTicket) {
		super();
		this.codTicket = codTicket;
		this.productos = new ArrayList<Producto>();
	}
	public Boolean agregarProducto(Producto producto) {
		if (producto!=null) {
			return this.productos.add(producto);
		}
		return false;
	}
	public Double calcularSubtotal() {
		Double calculo=0.;
		for(Producto producto: this.productos) {
			calculo += producto.getPrecio();
		}
		return calculo;
	}
	public ArrayList<Producto> getProductos() {
		return this.productos;
	}
	public abstract Double calcularTotal();
	
	public String getCodigo() {
		return this.codTicket;
	}
	
	
	
}
