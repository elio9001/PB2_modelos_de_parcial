package ar.supermercado;

public class Producto {
	private Integer codigo;
	private String nombre;
	private Double precio;
	
	public Producto(Integer codigo, String nombre, Double precio) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
	}

	public Double getPrecio() {
		return this.precio;
	}
	
}
