package ar.supermercado;

public class TicketFactura extends Ticket {
	private final Double IVA = 21.;
	public TicketFactura(String codTicket) {
		super(codTicket);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double calcularTotal() {
		Double recargoIVA = (super.calcularSubtotal()*IVA)/100;
		Double calculoTotal = super.calcularSubtotal() + recargoIVA;
		return calculoTotal;
	}

}
