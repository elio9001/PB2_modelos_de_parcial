package ar.supermercado;

import java.util.ArrayList;

public class Supermercado {
	private String nombre;
	private ArrayList<Ticket> colaDeTickets;
	private ArrayList<Ticket> ticketsProcesados;

	public Supermercado(String nombre) {
		this.nombre = nombre;
		this.colaDeTickets = new ArrayList<Ticket>();
		this.ticketsProcesados = new ArrayList<Ticket>();
	}

	public Boolean encolarTicket(Ticket ticket) {
		if (ticket != null) {
			return this.colaDeTickets.add(ticket);
		}
		return false;
	}

	public Integer getCantidadTicketsPendientes() {
		return this.colaDeTickets.size();
	}

	public Ticket cobrarProximoTicket() {
		if (getCantidadTicketsPendientes() > 0) {
			int primerTicket = 0;
			Ticket ticketProcesado = this.colaDeTickets.get(primerTicket);
			this.ticketsProcesados.addLast(ticketProcesado);
			this.colaDeTickets.remove(primerTicket);
			return ticketProcesado;
		}
		return null;
	}

	public Integer getCantidadTicketsCobrados() {
		return this.ticketsProcesados.size();
	}

	public Ticket buscarTicketCobradoPorCodigo(String codTicket) {
		for (Ticket ticket : this.ticketsProcesados) {
			if (ticket.getCodigo().equals(codTicket)) {
				return ticket;
			}
		}
		return null;
	}

	public Double montoRecaudado() {
		Double monto=0.;
		for(Ticket ticket : this.ticketsProcesados) {
			monto += ticket.calcularTotal();
		}
		return monto;
	}

	public Double montoPendienteEnCola() {
		Double monto=0.;
		for(Ticket ticket : this.colaDeTickets) {
			monto += ticket.calcularTotal();
		}
		return monto;
	}
	

}
