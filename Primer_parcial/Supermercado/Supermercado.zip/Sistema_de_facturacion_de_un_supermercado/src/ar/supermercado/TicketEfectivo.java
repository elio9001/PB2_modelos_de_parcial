package ar.supermercado;

public class TicketEfectivo extends Ticket {
	private final Double DESCUENTO = 10.;
	public TicketEfectivo(String codTicket) {
		super(codTicket);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double calcularTotal() {
		Double montoDescuento = (super.calcularSubtotal() * DESCUENTO)/100;
		Double calculoTotal = super.calcularSubtotal() - montoDescuento;
		return calculoTotal;
	}

}
