package ar.supermercado;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class prueba {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Before
	public void asdf() {}

}
