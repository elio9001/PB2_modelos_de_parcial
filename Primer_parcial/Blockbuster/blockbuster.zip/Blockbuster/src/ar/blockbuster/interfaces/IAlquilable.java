package ar.blockbuster.interfaces;

import ar.blockbuster.enumeracion.Clasificacion;

public interface IAlquilable {
	public Double precioAlquiler();
	public Clasificacion obtenerClasificacion();
}
