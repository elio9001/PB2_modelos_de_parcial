package ar.blockbuster.interfaces;

public interface IVendible {
	public Double precioDeVenta();
}
