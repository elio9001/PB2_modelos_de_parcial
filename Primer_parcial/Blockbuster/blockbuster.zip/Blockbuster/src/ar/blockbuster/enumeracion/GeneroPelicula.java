package ar.blockbuster.enumeracion;

public enum GeneroPelicula {
	INFANTIL, COMEDIA,ACCION,TERROR, SUSPENSO;
}
