package ar.blockbuster.enumeracion;

public enum Estado {
	DISPONIBLE, VENDIDO, ALQUILADO;
}
