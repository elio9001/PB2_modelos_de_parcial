package ar.blockbuster.enumeracion;

public enum Clasificacion {
	ATP, MAYORES_DE_7, MAYORES_DE_18;
}
