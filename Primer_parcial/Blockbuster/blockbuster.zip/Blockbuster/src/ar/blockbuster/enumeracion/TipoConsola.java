package ar.blockbuster.enumeracion;

public enum TipoConsola {
	PC, PLAYSTATION, XBOX, NINTENDO;
}
