package ar.blockbuster;

import java.util.Objects;

import ar.blockbuster.enumeracion.Estado;

public class Producto{
	private Integer codigo;
	private String descripcion;
	private Estado estado;
	public Producto(Integer codigo,String descripcion) {
		super();
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.estado = Estado.DISPONIBLE;
	}
	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return Objects.equals(codigo, other.codigo);
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Estado getEstado() {
		return estado;
	}
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
	

}
