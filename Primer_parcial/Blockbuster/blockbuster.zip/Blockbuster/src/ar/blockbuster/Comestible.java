package ar.blockbuster;

import ar.blockbuster.interfaces.IVendible;

public class Comestible extends Producto implements IVendible{

	public Comestible(Integer codigo, String descripcion) {
		super(codigo, descripcion);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double precioDeVenta() {
		Double precio = 1000.;
			return precio;
		}




}
