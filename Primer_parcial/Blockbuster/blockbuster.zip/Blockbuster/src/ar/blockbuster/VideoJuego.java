package ar.blockbuster;

import ar.blockbuster.enumeracion.Clasificacion;
import ar.blockbuster.enumeracion.TipoConsola;
import ar.blockbuster.interfaces.IAlquilable;

public class VideoJuego extends Producto implements IAlquilable{
	private TipoConsola tipo;
	private Clasificacion clasificacion;
	public VideoJuego(Integer codigo, String descripcion, TipoConsola tipo, Clasificacion clasificacion) {
		super(codigo, descripcion);
		this.tipo = tipo;
		this.clasificacion = clasificacion;
	}

	@Override
	public Double precioAlquiler() {
		Double precio = 3000.;
		return precio;
	}

	@Override
	public Clasificacion obtenerClasificacion() {
		return clasificacion;
	}

}
