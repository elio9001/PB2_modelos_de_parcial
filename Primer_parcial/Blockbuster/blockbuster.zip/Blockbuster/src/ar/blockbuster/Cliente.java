package ar.blockbuster;

public class Cliente {
	private Integer idCliente;
	private String nombre;
	private String apellido;
	private Integer edad;

	public Cliente(Integer idCliente, String nombre, String apellido, Integer edad) {
		super();
		this.idCliente = idCliente;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
	}

	public Integer getEdad() {
		return edad;
	}

	public void setEdad(Integer edad) {
		this.edad = edad;
	}

}
