package ar.blockbuster;

import java.util.ArrayList;

import ar.blockbuster.enumeracion.Clasificacion;
import ar.blockbuster.enumeracion.GeneroPelicula;
import ar.blockbuster.interfaces.IAlquilable;
import ar.blockbuster.interfaces.IVendible;

public class Pelicula extends Producto implements IVendible, IAlquilable {
	private GeneroPelicula genero;
	private Integer anioDeEstreno;
	private String director;
	private ArrayList<String> actores;
	private Clasificacion clasificacion;

	public Pelicula(Integer codigo, String descripcion, GeneroPelicula genero, Integer anioEstreno, String director,Clasificacion clasificacion) {
		super(codigo, descripcion);
		this.actores = new ArrayList<String>();
		this.clasificacion = clasificacion;
	}

	public void agregarActor(String nombreActor) {
		if (nombreActor != null)
			this.actores.add(nombreActor);
	}

	@Override
	public Double precioDeVenta() {
		Double precio = 20000.;
		return precio;
	}

	@Override
	public Double precioAlquiler() {
		Double precio = 3000.;
		return precio;
	}

	@Override
	public Clasificacion obtenerClasificacion() {
		return clasificacion;
	}

}
