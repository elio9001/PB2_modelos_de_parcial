package ar.blockbuster;

public class Operacion {
	private Integer idOperacion;
	private Cliente cliente;
	private Producto producto;
	private static Integer nuevoId = 1;
	
	public Operacion(Cliente cliente, Producto producto,Double precio) {
		super();
		this.cliente = cliente;
		this.producto = producto;
		this.idOperacion= nuevoId;
		nuevoId++;
	}
	
	public void resetearId() {
		nuevoId=1;
	}

}
