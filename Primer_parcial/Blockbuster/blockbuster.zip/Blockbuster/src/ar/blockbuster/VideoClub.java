package ar.blockbuster;

import java.util.ArrayList;
import java.util.HashSet;

import ar.blockbuster.enumeracion.Clasificacion;
import ar.blockbuster.interfaces.IAlquilable;
import ar.blockbuster.interfaces.IVendible;

public class VideoClub {
	HashSet<Operacion> operaciones;

	public VideoClub() {
		super();
		this.operaciones = new HashSet<Operacion>();
	}

	public Boolean venderUnProducto(Cliente cliente, Producto producto) {
		if (producto != null && producto instanceof IVendible) {
			if (producto != null && cliente != null) {
				Double precio = ((IVendible) producto).precioDeVenta();
				Operacion op = new Operacion(cliente, producto, precio);
				return this.operaciones.add(op);
			}
		}

		return false;
	}

	public Boolean alquilarUnProducto(Cliente cliente, Producto producto) {
		if (producto != null && producto instanceof IAlquilable) {
			if (cliente != null && verificarEdad(cliente, producto)) {
				Double precio = ((IAlquilable) producto).precioAlquiler();
				Operacion op = new Operacion(cliente, producto, precio);
				return this.operaciones.add(op);
			}
		}
		return false;
	}

	public Integer cantidadDeOperaciones() {
		return operaciones.size();
	}

	public void alquilarDosProductos(Cliente cliente, Producto producto1, Producto producto2) {
		ArrayList<Producto> productos = new ArrayList<Producto>();
		productos.add(producto1);
		productos.add(producto2);
		if (verificarLosProductosAAlquilar(productos)) {
			for (Producto produ : productos) {
				if (verificarEdad(cliente, produ)) {
					Double precio = ((IAlquilable) produ).precioAlquiler();
					Operacion op = new Operacion(cliente, produ, precio);
					this.operaciones.add(op);
				}
			}
		}

	}

	public Boolean verificarLosProductosAAlquilar(ArrayList<Producto> productos) {
		Integer contador = 0;
		for (Producto produ : productos) {
			if (produ != null && produ instanceof IAlquilable) {
				contador++;
			}
		}
		if (contador == 2) {
			return true;
		}

		return false;
	}

	public Boolean verificarEdad(Cliente cliente, Producto producto) {
		IAlquilable prodAlquilable = ((IAlquilable) producto);
		if (prodAlquilable.obtenerClasificacion().equals(Clasificacion.ATP)) {
			return true;
		}
		if (cliente.getEdad() > 7 && prodAlquilable.obtenerClasificacion().equals(Clasificacion.MAYORES_DE_7)) {
			return true;
		}
		if (cliente.getEdad() > 18 && prodAlquilable.obtenerClasificacion().equals(Clasificacion.MAYORES_DE_18)) {
			return true;
		}
		return false;
	}

}
