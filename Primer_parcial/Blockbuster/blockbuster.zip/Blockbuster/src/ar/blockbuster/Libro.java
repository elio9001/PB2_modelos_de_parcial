package ar.blockbuster;

import ar.blockbuster.interfaces.IVendible;

public class Libro extends Producto implements IVendible {

	public Libro(Integer codigo, String descripcion) {
		super(codigo, descripcion);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double precioDeVenta() {
	Double precio = 10000.;
		return precio;
	}


	

}
