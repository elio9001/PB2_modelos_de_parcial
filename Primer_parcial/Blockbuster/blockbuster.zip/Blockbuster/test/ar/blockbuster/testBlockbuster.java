package ar.blockbuster;

import static org.junit.Assert.*;

import org.junit.Test;

import ar.blockbuster.enumeracion.Clasificacion;
import ar.blockbuster.enumeracion.GeneroPelicula;
import ar.blockbuster.enumeracion.TipoConsola;

public class testBlockbuster {

	@Test
	public void seRealizaLaVentaDeUnProducto() {
		VideoClub vc = new VideoClub();

		Comestible com1 = new Comestible(1, "nada");
		Cliente cliente1 = new Cliente(111, "marcos", "galperin", 20);

		assertTrue(vc.venderUnProducto(cliente1, com1));

		Integer cantidadObtenida = vc.cantidadDeOperaciones();
		Integer cantidadEseperada = 1;

		assertEquals(cantidadEseperada, cantidadObtenida);
	}

	@Test
	public void seRealizanDosAlquileresAlMismoTiempo() {
		VideoClub vc = new VideoClub();

		VideoJuego vj1= new VideoJuego(111, "gta 5", TipoConsola.PLAYSTATION,Clasificacion.MAYORES_DE_18);
		Pelicula p1= new Pelicula(222, "the thing", GeneroPelicula.TERROR, 1980, "john carpenter",Clasificacion.MAYORES_DE_18);
		Cliente cliente1 = new Cliente(111, "leo", "messi", 20);
		
		vc.alquilarDosProductos(cliente1,p1,vj1);

		Integer cantidadObtenida = vc.cantidadDeOperaciones();
		Integer cantidadEseperada = 2;

		assertEquals(cantidadEseperada, cantidadObtenida);
	}
	
	@Test
	public void noSePuedenVenderProductosNoVendibles() {
		VideoClub vc = new VideoClub();

		VideoJuego vj1= new VideoJuego(111, "gta 5", TipoConsola.PLAYSTATION,Clasificacion.MAYORES_DE_18);
		Cliente cliente1 = new Cliente(111, "mario", "martinez", 20);
		
		vc.venderUnProducto(cliente1, vj1);

		Integer cantidadObtenida = vc.cantidadDeOperaciones();
		Integer cantidadEseperada = 0;

		assertEquals(cantidadEseperada, cantidadObtenida);
	}
	
	@Test
	public void noSePuedeAlquilarUnProductoNoAptoParaMenoresDeEdad() {
		VideoClub vc = new VideoClub();

		VideoJuego vj1= new VideoJuego(111, "GOW 2", TipoConsola.PLAYSTATION,Clasificacion.MAYORES_DE_18);
		Cliente cliente1 = new Cliente(111, "mario", "martinez", 17);
		
		vc.alquilarUnProducto(cliente1, vj1);

		Integer cantidadObtenida = vc.cantidadDeOperaciones();
		Integer cantidadEseperada = 0;

		assertEquals(cantidadEseperada, cantidadObtenida);
	}

}
