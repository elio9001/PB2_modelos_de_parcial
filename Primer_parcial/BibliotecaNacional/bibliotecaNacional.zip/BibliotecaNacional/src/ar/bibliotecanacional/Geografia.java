package ar.bibliotecanacional;

public class Geografia extends Libro implements IFotocopiable{

	public Geografia(Integer codigo, String nombre, String autor) {
		super(codigo, nombre, autor);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String fotoCopiar() {
		return "Los contienentes..";
	}

}
