package ar.bibliotecanacional;

import java.util.ArrayList;
import java.util.HashSet;

public class Biblioteca {
	HashSet<Libro> libros;
	HashSet<Prestamo> prestamos;

	public Biblioteca() {
		this.libros = new HashSet<Libro>();
		this.prestamos = new HashSet<Prestamo>();
	}

	public void registrarUnLibro(Libro libro) {
		if (libro != null) {
			libros.add(libro);
		}

	}

	public Integer cantidadDeLibrosRegistrados() {
		return libros.size();
	}

	public void registrarElPrestamoDeDosLibros(Alumno alumno, Integer idLibro1, Integer idLibro2) {
		ArrayList<Integer> librosAPrestar = new ArrayList<Integer>();
		librosAPrestar.add(idLibro1);
		librosAPrestar.add(idLibro2);

		if (alumno != null) {
			for (Integer codigo : librosAPrestar) {
				Libro libro = buscarLibroPorCodigo(codigo);
				if (libro != null && libro.sePuedePrestar()) {
					this.prestamos.add(new Prestamo(alumno, libro));
					libro.prestar();
				}
			}
		}

	}

	private Libro buscarLibroPorCodigo(Integer idLibro) {
		for (Libro libro : libros) {
			if (libro.getCodigo().equals(idLibro)) {
				return libro;
			}
		}
		return null;
	}

	public Integer cantidadDePrestamosRegistrados() {
		return prestamos.size();
	}

	public Boolean disponibilidadDeUnLibro(Integer idLibro) {
		Libro libroEncontrado = buscarLibroPorCodigo(idLibro);

		if (libroEncontrado != null) {
			return libroEncontrado.sePuedePrestar();
		}
		
		return null;
	}

	public String fotocopiarUnLibro(Integer idLibro) {
		Libro libroEncontrado = buscarLibroPorCodigo(idLibro);
		if (libroEncontrado!=null && libroEncontrado instanceof IFotocopiable) {
			return ((IFotocopiable)libroEncontrado).fotoCopiar();
		}
		return null;
	}

}
