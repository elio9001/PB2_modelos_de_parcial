package ar.bibliotecanacional;

import java.util.Objects;

public class Libro {
	private Integer codigo;
	private String nombre;
	private String autor;
	private Boolean disponible;

	public Libro(Integer codigo,String nombre,String autor) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.autor = autor;
		this.disponible = true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		Libro other = (Libro) obj;
		return Objects.equals(codigo, other.codigo);
	}

	public Integer getCodigo() {
		// TODO Auto-generated method stub
		return codigo;
	}
	public Boolean sePuedePrestar() {
		return disponible;
	}
	public void prestar() {
		disponible = false;
	}
	
}
