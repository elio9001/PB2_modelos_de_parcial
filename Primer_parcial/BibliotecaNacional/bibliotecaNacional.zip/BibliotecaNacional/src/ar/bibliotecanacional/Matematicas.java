package ar.bibliotecanacional;

public class Matematicas extends Libro{

	public Matematicas(Integer codigo, String nombre, String autor) {
		super(codigo, nombre, autor);
		// TODO Auto-generated constructor stub
	}

}
