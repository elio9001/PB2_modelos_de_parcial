package ar.bibliotecanacional;

public interface IFotocopiable {
	String fotoCopiar();
}
