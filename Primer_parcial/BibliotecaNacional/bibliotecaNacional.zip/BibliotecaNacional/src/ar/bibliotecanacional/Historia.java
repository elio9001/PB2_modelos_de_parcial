package ar.bibliotecanacional;

public class Historia extends Libro implements IFotocopiable{

	public Historia(Integer codigo, String nombre, String autor) {
		super(codigo, nombre, autor);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String fotoCopiar() {
		return "la primera guerra mundial...";
	}
	
}
