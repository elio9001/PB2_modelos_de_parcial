package ar.bibliotecanacional;

public class Prestamo {
	private static Integer nuevoId=1;
	private Integer idPrestamo;
	private Alumno alumno;
	private Libro libro;

	public Prestamo(Alumno alumno, Libro libro) {
		this.alumno = alumno;
		this.libro = libro;
		this.idPrestamo = nuevoId;
		nuevoId++;
	}
}
