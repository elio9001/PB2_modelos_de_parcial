package ar.bibliotecanacional;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBibliotecaNacional {

	@Test
	public void dadoQueExisteUnaBibliotecaSeRegistranTresTiposDeLibros() {
		Biblioteca ba = new Biblioteca();

		Historia h1 = new Historia(111, "Hisoria1", "alguien");
		Geografia g1 = new Geografia(222, "Geografia1", "alguien");
		Matematicas m1 = new Matematicas(333, "Matematica1", "alguien");

		ba.registrarUnLibro(h1);
		ba.registrarUnLibro(g1);
		ba.registrarUnLibro(m1);
		// ba.cantidadDeLibrosRegistrados();
		assertEquals(3, ba.cantidadDeLibrosRegistrados(), 0.01);
	}

	@Test
	public void noSePuedenRegistrardosLibrosConElcodigo() {
		Biblioteca ba = new Biblioteca();

		Historia h1 = new Historia(111, "Hisoria1", "alguien");
		Geografia g1 = new Geografia(111, "Geografia1", "alguien");

		ba.registrarUnLibro(h1);
		ba.registrarUnLibro(g1);
		Integer cantidadObtenida = ba.cantidadDeLibrosRegistrados();
		Integer cantidadEsperada = 1;

		assertEquals(cantidadEsperada, cantidadObtenida);
	}

	@Test
	public void seRegistranDosPrestamosSimultaneamente() {
		Biblioteca ba = new Biblioteca();

		Historia h1 = new Historia(111, "Hisoria1", "alguien");
		Geografia g1 = new Geografia(222, "Geografia1", "alguien");

		ba.registrarUnLibro(h1);
		ba.registrarUnLibro(g1);
		Integer dni = 1234;
		String nombre = "jotaro";
		String apellido = "kujo"; 
		Alumno alumno1 = new Alumno(dni,nombre,apellido);
		ba.registrarElPrestamoDeDosLibros(alumno1,111,222);
		
		Integer cantidadObtenida = ba.cantidadDePrestamosRegistrados();
		Integer cantidadEsperada = 2;
		
		assertEquals(cantidadEsperada, cantidadObtenida);
	}
	
	@Test
	public void verificarSiUnLibroEstaDisplibleLuegoDeSerPrestado() {
		Biblioteca ba = new Biblioteca();

		Historia h1 = new Historia(111, "Hisoria1", "alguien");
		Geografia g1 = new Geografia(222, "Geografia1", "alguien");

		ba.registrarUnLibro(h1);
		ba.registrarUnLibro(g1);
		Integer dni = 1234;
		String nombre = "jotaro";
		String apellido = "kujo"; 
		Alumno alumno1 = new Alumno(dni,nombre,apellido);
		ba.registrarElPrestamoDeDosLibros(alumno1,111,222);
		
		Boolean estaDisponible = ba.disponibilidadDeUnLibro(111);
		assertFalse(estaDisponible);
	}
	
	@Test
	public void fotoCopiarUnLibroDeLaBiblioteca() {
		Biblioteca ba = new Biblioteca();

		Historia h1 = new Historia(111, "Hisoria1", "alguien");
		Geografia g1 = new Geografia(222, "Geografia1", "alguien");

		ba.registrarUnLibro(h1);
		ba.registrarUnLibro(g1);
		
		String fotocopiaObtenida = ba.fotocopiarUnLibro(111);
		String fotocopiaEsperada = "la primera guerra mundial...";
		
		assertEquals(fotocopiaEsperada, fotocopiaObtenida);
	}

}
