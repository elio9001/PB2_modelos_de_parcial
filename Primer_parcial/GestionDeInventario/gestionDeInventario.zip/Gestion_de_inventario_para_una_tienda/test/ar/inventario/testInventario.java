package ar.inventario;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

public class testInventario {
	@Test
	public void queMePermitaAgregarALaTiendaUnProductoPerecedero() {
		Tienda tienda = new Tienda();

		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = false;
		Perecedero p1 = new Perecedero(111, "pan", 30, fecha, 500., false, 20., estaVencido);

		Boolean seAgrego = tienda.agregarProducto(p1);
		assertTrue(seAgrego);

	}

	@Test
	public void queMeNoPermitaAgregarALaTiendaUnProductoPersederoConElMismoCodigoYNOmbre() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = false;
		Perecedero p1 = new Perecedero(111, "pan", 30, fecha, 500., false, 20., estaVencido);
		Perecedero p2 = new Perecedero(111, "pan", 30, fecha, 500., false, 20., estaVencido);

		tienda.agregarProducto(p1);
		Boolean seAgrego = tienda.agregarProducto(p2);

		assertFalse(seAgrego);
	}

	@Test
	public void queMePermitaAgregarALaTiendaUnProductoNoPersedero() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		NoPerecedero p1 = new NoPerecedero(111, "azucar", 15, fecha, 1500., Categoria.DULCE, fecha, "nada");

		Boolean seAgrego = tienda.agregarProducto(p1);
		assertTrue(seAgrego);

	}

	@Test
	public void queMeNoPermitaAgregarALaTiendaUnProductoNOPersederoConElMismoCodigoYNOmbre() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		NoPerecedero p1 = new NoPerecedero(111, "azucar", 30, fecha, 500., Categoria.DULCE, fecha, "nada");
		NoPerecedero p2 = new NoPerecedero(111, "azucar", 30, fecha, 500., Categoria.DULCE, fecha, "nada");
		tienda.agregarProducto(p1);
		Boolean seAgrego = tienda.agregarProducto(p2);

		assertFalse(seAgrego);
	}

	@Test
	public void quePermitaCalcularElPrecioFinalDeUnProductoPersederoCorrectamnte() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = false;
		Perecedero p1 = new Perecedero(111, "pan", 30, fecha, 1000., false, 20., estaVencido);

		tienda.agregarProducto(p1);
		Double precioObtenido = tienda.calcularPrecioFinalDeUnProducto(111);
		Double precioEsperado = 1050.;

		assertEquals(precioEsperado, precioObtenido);
	}

	@Test
	public void quePermitaCalcularElPrecioFinalDeUnProductoNoPersederoCorrectamnte() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);

		NoPerecedero p1 = new NoPerecedero(111, "azucar", 15, fecha, 1500., Categoria.DULCE, fecha, "nada");
		tienda.agregarProducto(p1);
		Double precioObtenido = tienda.calcularPrecioFinalDeUnProducto(111);
		Double precioEsperado = 1605.;

		assertEquals(precioEsperado, precioObtenido);
	}

	@Test
	public void quePermitaCalcularElPrecioFinalDeInventarioDeLosProductoPersederoCorrectamnte() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = false;
		
		Perecedero p1 = new Perecedero(111, "pan", 30, fecha, 1000., false, 20., estaVencido);
		Perecedero p2 = new Perecedero(222, "pan", 30, fecha, 1000., false, 20., estaVencido);
		
		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		
		Double precioObtenido = tienda.calcularPrecioFinalDeLosProductosPerecederos();
		Double precioEsperado = 2100.;

		assertEquals(precioEsperado, precioObtenido);
	}

	// 8)
	@Test
	public void quePermitaCalcularElPrecioFinalDeInventarioDeLosProductoNoPersederoCorrectamente() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);

		NoPerecedero p1 = new NoPerecedero(111, "azucar", 15, fecha, 1500., Categoria.DULCE, fecha, "nada");
		NoPerecedero p2 = new NoPerecedero(222, "azucar", 15, fecha, 1500., Categoria.DULCE, fecha, "nada");
		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		Double precioObtenido = tienda.calcularPrecioFinalDeLosProductoNoPerecederos();
		Double precioEsperado = 3210.;

		assertEquals(precioEsperado, precioObtenido);
	}

	// 9)
	@Test
	public void queMePermitaCalcularElPrecioFinalDelInventarioConTodosLosProductos() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = false;
		NoPerecedero p1 = new NoPerecedero(111, "azucar", 15, fecha, 1500., Categoria.DULCE, fecha, "nada");
		Perecedero p2 = new Perecedero(22, "pan", 30, fecha, 1000., false, 20., estaVencido);
		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		Double precioObtenido = tienda.calcularPrecioFinalDeTodoElInventario();
		Double precioEsperado = 2655.;

		assertEquals(precioEsperado, precioObtenido);
	}

	// 10)
	@Test
	public void queMePermitaObtenerLosProductosNoPersederosSinStock() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);

		NoPerecedero p1 = new NoPerecedero(111, "azucar", 0, fecha, 1500., Categoria.DULCE, fecha, "nada");
		NoPerecedero p2 = new NoPerecedero(222, "azucar", 1, fecha, 1500., Categoria.DULCE, fecha, "nada");
		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		Integer cantidadDeProductosSinStock = tienda.obtenerLosProductosNoPerecederosSinStock().size();
		Integer cantidadEsperada = 1;

		assertEquals(cantidadEsperada, cantidadDeProductosSinStock);
	}

	@Test
	public void queMePermitaObtenerLosProductosPersederosSinStock() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = false;
		Perecedero p1 = new Perecedero(111, "pan", 0, fecha, 1000., false, 20., estaVencido);
		Perecedero p2 = new Perecedero(222, "pan", 0, fecha, 1000., false, 20., estaVencido);

		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		Integer cantidadDeProductosSinStock = tienda.obtenerLosProductosPerecederosSinStock().size();
		Integer cantidadEsperada = 2;

		assertEquals(cantidadEsperada, cantidadDeProductosSinStock);
	}

	@Test
	public void queMePermitaObtenerTodosLosProductosEnEstadoCaducados() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = true;
		Perecedero p1 = new Perecedero(111, "pan", 0, fecha, 1000., true, 20., estaVencido);
		Perecedero p2 = new Perecedero(222, "pan", 0, fecha, 1000., true, 20., estaVencido);

		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		Integer cantidadDeProductosCaducados = tienda.obtenerLosProductosCaducados().size();
		Integer cantidadEsperada = 2;

		assertEquals(cantidadEsperada, cantidadDeProductosCaducados);
	}

	@Test
	public void queMePermitaObtenerElPromedioDeTemperaturaDeConservacionDeLosProductosPersederos() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);
		Boolean estaVencido = true;
		Perecedero p1 = new Perecedero(111, "pan", 0, fecha, 1000., true, 20., estaVencido);
		Perecedero p2 = new Perecedero(222, "pan", 0, fecha, 1000., true, 25., estaVencido);

		tienda.agregarProducto(p1);
		tienda.agregarProducto(p2);
		Double temperaturaPromedioObtenida = tienda.temperaturaPromedioDeLosProductosPeresederos();
		Double temperaturaEsperada = 22.5;

		assertEquals(temperaturaEsperada, temperaturaPromedioObtenida);
	}

	@Test
	public void queMePermitaExtenderLaGarantiaEn5DiasUnProductoNoPersedero() {
		Tienda tienda = new Tienda();
		LocalDate fecha = LocalDate.of(2026, 9, 20);

		NoPerecedero p1 = new NoPerecedero(111, "azucar", 0, fecha, 1500., Categoria.DULCE, fecha, "nada");
		tienda.agregarProducto(p1);

		Integer diasExtra = 5;
		tienda.extenderLaGarantiaDeUnProductoNoPerecedero(111, diasExtra);

		Integer diasDeGaratiaDeUnProducto = tienda.garantiaDeUnProductoNoPerecedero(111).getDayOfMonth();
		Integer diasEsperado = 25;

		assertEquals(diasEsperado, diasDeGaratiaDeUnProducto);
	}

}
