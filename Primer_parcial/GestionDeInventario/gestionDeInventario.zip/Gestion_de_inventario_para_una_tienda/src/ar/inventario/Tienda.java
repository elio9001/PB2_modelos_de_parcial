package ar.inventario;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;

public class Tienda {
	private HashSet<Producto> productos;

	public Tienda() {
		super();
		this.productos = new HashSet<Producto>();
	}

	public Boolean agregarProducto(Producto producto) {
		if (producto != null) {
			return this.productos.add(producto);
		}

		return false;
	}

	public Double calcularPrecioFinalDeUnProducto(Integer codProdu) {
		Producto productoEcontrado = buscarProductoPorCodigo(codProdu);
		if (productoEcontrado != null) {
			return productoEcontrado.precioFinal();
		}
		return 0.0;
	}

	private Producto buscarProductoPorCodigo(Integer codProdu) {
		for (Producto producto : productos) {
			if (producto.getCodProducto().equals(codProdu)) {
				return producto;
			}
		}
		return null;
	}

	public Double calcularPrecioFinalDeLosProductosPerecederos() {
		Double sumaDePrecios = 0.;
		for (Producto producto : productos) {
			if (producto instanceof Perecedero) {
				sumaDePrecios += producto.precioFinal();
			}
		}
		return sumaDePrecios;
	}

	public Double calcularPrecioFinalDeLosProductoNoPerecederos() {
		Double sumaDePrecios = 0.;
		for (Producto producto : productos) {
			if (producto instanceof NoPerecedero) {
				sumaDePrecios += producto.precioFinal();
			}
		}
		return sumaDePrecios;
	}

	public Double calcularPrecioFinalDeTodoElInventario() {
		Double sumaDePrecios = 0.;
		for (Producto producto : productos) {
			sumaDePrecios += producto.precioFinal();
		}
		return sumaDePrecios;
	}

	public ArrayList<Producto> obtenerLosProductosNoPerecederosSinStock() {
		ArrayList<Producto> productosSinStock = new ArrayList<Producto>();
		for (Producto producto : productos) {
			if (producto instanceof NoPerecedero && producto.getCantidadDisponible().equals(0)) {
				productosSinStock.add(producto);
			}
		}
		return productosSinStock;
	}

	public ArrayList<Producto> obtenerLosProductosPerecederosSinStock() {
		ArrayList<Producto> productosSinStock = new ArrayList<Producto>();
		for (Producto producto : productos) {
			if (producto instanceof Perecedero && producto.getCantidadDisponible().equals(0)) {
				productosSinStock.add(producto);
			}
		}
		return productosSinStock;
	}

	public ArrayList<Producto> obtenerLosProductosCaducados() {
		ArrayList<Producto> productosCaducados = new ArrayList<Producto>();
		for (Producto producto : productos) {
			if (producto instanceof ICaducable) {
				boolean estaCaducado = ((ICaducable) producto).estaCaducado();
				if (estaCaducado) {
					productosCaducados.add(producto);
				}
			}
		}
		return productosCaducados;
	}

	public Double temperaturaPromedioDeLosProductosPeresederos() {
		Double sumaDeTemperaturas = 0.;
		Integer cantidad = 0;
		for (Producto producto : productos) {
			if (producto instanceof Perecedero) {
				sumaDeTemperaturas += ((Perecedero) producto).getTemperaturaDeConservacion();
				cantidad++;
			}
		}
		if (cantidad != 0) {
			return sumaDeTemperaturas / cantidad;
		}

		return null;
	}

	public void extenderLaGarantiaDeUnProductoNoPerecedero(Integer codProdu, Integer diasExtra) {
		Producto productoEncontrado = buscarProductoPorCodigo(codProdu);
		if (productoEncontrado != null && productoEncontrado instanceof NoPerecedero) {
			((NoPerecedero) productoEncontrado).extederDiasDeGarantia(diasExtra);
		}

	}

	public LocalDate garantiaDeUnProductoNoPerecedero(Integer codProd) {
		Producto productoEncontrado = buscarProductoPorCodigo(codProd);
		if (productoEncontrado != null && productoEncontrado instanceof NoPerecedero) {
			return ((NoPerecedero) productoEncontrado).getFechaDeVencimiento();
		}
		return null;
	}

}
