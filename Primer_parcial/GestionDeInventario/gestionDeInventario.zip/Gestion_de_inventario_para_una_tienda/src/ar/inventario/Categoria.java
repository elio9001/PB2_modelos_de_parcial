package ar.inventario;

public enum Categoria {
	DESPENSA,DULCE;
}
