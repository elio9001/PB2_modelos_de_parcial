package ar.inventario;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Producto {
	private Integer codProducto;
	private String nombre;
	private Integer cantidadDisponible;
	private LocalDate fechaIngreso;
	private Double precioUnitario;

	public Producto(Integer codProducto, String nombre, Integer cantidadDisponible, LocalDate fechaIngreso,
			Double precioUnitario) {
		super();
		this.codProducto = codProducto;
		this.nombre = nombre;
		this.cantidadDisponible = cantidadDisponible;
		this.fechaIngreso = fechaIngreso;
		this.precioUnitario = precioUnitario;
	}

	public Integer getCodProducto() {
		return codProducto;
	}

	public void setCodProducto(Integer codProducto) {
		this.codProducto = codProducto;
	}

	public Double getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(Double precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public Integer getCantidadDisponible() {
		return cantidadDisponible;
	}

	public void setCantidadDisponible(Integer cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public LocalDate getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(LocalDate fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public abstract Double precioFinal();

	@Override
	public int hashCode() {
		return Objects.hash(codProducto, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return Objects.equals(codProducto, other.codProducto) && Objects.equals(nombre, other.nombre);
	}

}
