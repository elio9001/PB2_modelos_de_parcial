package ar.inventario;

import java.time.LocalDate;

public class Perecedero extends Producto implements ICaducable{
	private final Double porcentajeAdicional = 5.;
	private Boolean estaVencido;
	private Boolean requiereRefrigeracion;
	private Double temperaturaDeConservacion;
	public Perecedero(Integer codProducto,String nombre, Integer cantidadDisponible, LocalDate fechaIngreso, Double precioUnitario,Boolean refriferacion,Double temperaturaConservacion,Boolean estaVencido) {
		super(codProducto,nombre, cantidadDisponible, fechaIngreso, precioUnitario);
		this.estaVencido =estaVencido;
		this.requiereRefrigeracion = refriferacion;
		this.temperaturaDeConservacion = temperaturaConservacion;
	}
	
	public Double getTemperaturaDeConservacion() {
		return temperaturaDeConservacion;
	}

	public void setTemperaturaDeConservacion(Double temperaturaDeConservacion) {
		this.temperaturaDeConservacion = temperaturaDeConservacion;
	}

	@Override
	public Double precioFinal() {
		Double adicional = (super.getPrecioUnitario()*porcentajeAdicional)/100;
		Double calculo = super.getPrecioUnitario() + adicional;
		return calculo;
	}
	@Override
	public Boolean estaCaducado() {
		// TODO Auto-generated method stub
		return estaVencido;
	}

}
