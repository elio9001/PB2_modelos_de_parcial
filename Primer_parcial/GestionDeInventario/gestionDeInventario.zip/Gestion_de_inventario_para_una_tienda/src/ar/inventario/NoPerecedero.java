package ar.inventario;

import java.time.LocalDate;

public class NoPerecedero extends Producto {
	private final Double porcentajeAdicional = 7.;
	private Categoria categorio;
	private LocalDate fechaDeVencimiento;
	private String proveedor;

	public NoPerecedero(Integer codProducto, String nombre, Integer cantidadDisponible, LocalDate fechaIngreso,
			Double precioUnitario, Categoria categorio, LocalDate fechaDeVencimiento, String proveedor) {
		super(codProducto, nombre, cantidadDisponible, fechaIngreso, precioUnitario);
		this.categorio = categorio;
		this.fechaDeVencimiento = fechaDeVencimiento;
		this.proveedor = proveedor;
	}

	public void extederDiasDeGarantia(Integer dias) {
		this.fechaDeVencimiento = fechaDeVencimiento.plusDays(dias);
	}

	public LocalDate getFechaDeVencimiento() {
		return fechaDeVencimiento;
	}

	@Override
	public Double precioFinal() {
		Double adicional = (super.getPrecioUnitario() * porcentajeAdicional) / 100;
		Double calculo = super.getPrecioUnitario() + adicional;
		return calculo;
	}

}
