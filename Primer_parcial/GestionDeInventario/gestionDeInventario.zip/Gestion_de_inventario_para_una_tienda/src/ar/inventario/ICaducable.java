package ar.inventario;

public interface ICaducable {
	Boolean estaCaducado();
}
