package ar.banco;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;
import org.junit.Before;

public class BancoTest {

	private Banco banco;

	// NOTA LOS RESULTADOS PUEDEN VARIAR DEPENDIENDO DEL SALDO A LA HORA
	// DE AGREGAR UNA CUENTA
	@Before
	public void setUp() {
		banco = new Banco("Banco Escuela");
		banco.agregarCuenta(new CajaAhorro(1, "Ana", 500.));
		banco.agregarCuenta(new CuentaCorriente(2, "Luis", 500., 1000.));
	}

	// Depositar 50 devuelve true y el saldo pasa de 100 a 150 en la CajaAhorro.
	@Test
	public void depositarCajaAhorroDebeAumentarElSaldo() { //si da error mira con que saldo se creo y agrego la cuenta
		banco.depositar(1, 50.);
		Double saldoDeCuentaBuscada = banco.buscarCuenta(1).getSaldo();
		Double saldoEsperado = 150.;
		assertEquals(saldoEsperado, saldoDeCuentaBuscada);
	}

	// Extraer 50 de la CajaAhorro devuelve true. Se descuentan 50 + 5 de comisión:
	// el saldo final es 45.
	@Test
	public void extraerCajaAhorroDebeDescontarMontoMasComision() { //si da error mira con que saldo se creo y agrego la cuenta
		banco.extraer(1, 50.);
		Double saldoDeCuentaBuscada = banco.buscarCuenta(1).getSaldo();
		Double saldoEsperado = 45.;

		assertEquals(saldoEsperado, saldoDeCuentaBuscada);
	}

	// Extraer 1200 de la CuentaCorriente con id = 2 devuelve true y el saldo queda
	// en -700 (usa el descubierto).
	@Test
	public void extraerCuentaCorrienteUsandoElDescubiertoDebeDejarSaldoNegativo() {
		banco.extraer(2, 1200.);
		Double saldoDeCuentaBuscada = banco.buscarCuenta(2).getSaldo();
		Double saldoEsperado = -700.;

		assertEquals(saldoEsperado, saldoDeCuentaBuscada);
	}

	// Se declaran dos variables de tipo Transferible (CajaAhorro y CuentaCorriente,
	// saldo 500). Se llama extraer(100) sobre cada una. La caja queda en 395
	// (comisión) y la corriente en 400.
	@Test
	public void extraerSobreTransferibleDebeAplicarLaReglaDeCadaTipoDeCuenta() {
		banco.extraer(1, 100.);
		Double saldoDeCuentaBuscada1 = banco.buscarCuenta(1).getSaldo();
		Double saldoEsperado1 = 395.;
		assertEquals(saldoEsperado1, saldoDeCuentaBuscada1);

		banco.extraer(2, 100.);
		Double saldoDeCuentaBuscada2 = banco.buscarCuenta(2).getSaldo();
		Double saldoEsperado2 = 400.;
		assertEquals(saldoEsperado2, saldoDeCuentaBuscada2);

	}

	// Se guardan una CajaAhorro y una CuentaCorriente en un misma coleccion de
	// Cuenta. Se deposita 100 en cada una y se verifica que ambas subieron 100
	@Test
	public void depositarEnColeccionDeCuentasDebeTratarATodasPorIgual() {
		banco.depositar(1, 100.);
		Double saldoDeCuentaBuscada1 = banco.buscarCuenta(1).getSaldo();
		Double saldoEsperado1 = 600.;
		assertEquals(saldoEsperado1, saldoDeCuentaBuscada1);

		banco.depositar(2, 100.);
		Double saldoDeCuentaBuscada2 = banco.buscarCuenta(2).getSaldo();
		Double saldoEsperado2 = 600.;
		assertEquals(saldoEsperado2, saldoDeCuentaBuscada2);
	}

	// Agregar una CajaAhorro con id nuevo devuelve true y cantidadDeCuentas
	// aumenta.
	@Test
	public void agregarCajaAhorroNuevaDebeDevolverTrueYAumentarLaCantidad() {
		Boolean seAgrego = banco.agregarCuenta(new CajaAhorro(3, "Miyamoto", 1000.));
		assertTrue(seAgrego);

		Integer cantidadObtenida = banco.cantidadDeCuentas();
		Integer cantidadEsperada = 3;
		assertEquals(cantidadEsperada, cantidadObtenida);
	}

	// No debería permitir agregar una cuenta con id existente
	@Test
	public void noPermitirAgregarCajaDeAhorroConIdDuplicado() {
		Boolean seAgrego = banco.agregarCuenta(new CajaAhorro(2, "pedro", 9999.));
		assertFalse(seAgrego);
	}

	// Buscar una Cuenta Corriente con id 9 retorna null
	@Test
	public void buscarCuentaInexistenteDebeRetornarNull() {
		Cuenta cuentaBuscada = banco.buscarCuenta(9);
		assertNull(cuentaBuscada);
	}

	// Tras depositar en la CajaAhorro hay 1 movimiento: idCuenta 1, tipo DEPOSITO,
	// monto pedido.
	@Test
	public void depositarEnCajaAhorroDebeRegistrarUnMovimientoDeDeposito() {
		banco.depositar(1, 100.);
		
		Integer cantidadObtenida = banco.cantidadDeMovimientos();
		Integer cantidadEsperada = 1;
		assertEquals(cantidadEsperada, cantidadObtenida);
	}

	// Tras transferir entre CajaAhorro y CuentaCorriente hay 2 movimientos, en
	// orden: TRANSFERENCIA_ENVIADA y TRANSFERENCIA_RECIBIDA.
	@Test
	public void transferirEntreCajaAhorroYCuentaCorrienteDebeRegistrarMovimientoEnviadoYRecibido() {
		Boolean seTransfirio = banco.transferir(1, 2, 100.);
		Integer cantidadObtenida = banco.cantidadDeMovimientos();
		Integer cantidadEsperada = 2;
		assertEquals(cantidadEsperada, cantidadObtenida);
	}

	// transferir con destino inexistente devuelve false. El saldo de la CajaAhorro
	// origen no debe descontarse y no hay movimientos.
	@Test
	public void transferirConDestinoInexistenteNoDebeDescontarDeCajaAhorroOrigen() {
		Boolean seTransfirio = banco.transferir(1, 9, 100.);

		Integer cantidadObtenida = banco.cantidadDeMovimientos();
		Integer cantidadEsperada = 0;
		assertEquals(cantidadEsperada, cantidadObtenida);

		// Cuenta 1 saldo inicial 500.0
		Double saldoDeCuentaBuscada = banco.buscarCuenta(1).getSaldo();
		Double saldoEsperado = 500.;
		assertEquals(saldoEsperado, saldoDeCuentaBuscada);
	}

	// Se hace depositar, extraer y transferir. Se verifica que getMovimientos() los
	// devuelve en el orden cronológico en que ocurrieron.
	@Test
	public void depositarExtraerYTransferirDebeMantenerElOrdenCronologicoDeMovimientos() {
		banco.depositar(1, 100.);
		banco.extraer(1, 100.);
		banco.transferir(1, 2, 100.);

		ArrayList<Movimiento> movimientosRegistrados = banco.getMovimientos();
		assertEquals(TipoOperacion.DEPOSITO, movimientosRegistrados.get(0).getTipoOperacion());
		assertEquals(TipoOperacion.EXTRACCION, movimientosRegistrados.get(1).getTipoOperacion());
		assertEquals(TipoOperacion.TRANSFERENCIA_ENVIADA, movimientosRegistrados.get(2).getTipoOperacion());
		assertEquals(TipoOperacion.TRANSEFERENCIA_RECIBIDA, movimientosRegistrados.get(3).getTipoOperacion());
	}
        @Test
        public void decirHola(){
            Integer num1=3;
        }

}
