package ar.banco;

public enum TipoOperacion {
	DEPOSITO, EXTRACCION, TRANSFERENCIA_ENVIADA, TRANSEFERENCIA_RECIBIDA;
}
