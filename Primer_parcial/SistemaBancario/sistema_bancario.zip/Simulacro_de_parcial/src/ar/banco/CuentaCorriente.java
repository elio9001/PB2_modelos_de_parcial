package ar.banco;

public class CuentaCorriente extends Cuenta {
	private Double limiteDescubierto;
	public CuentaCorriente(Integer idCuenta, String titular, Double saldo,Double descubierto) {
		super(idCuenta, titular, saldo);
		this.limiteDescubierto = descubierto;
	}

	@Override
	public Boolean extraer(Double monto) {
		if (monto<=0 || monto>(getSaldo()+limiteDescubierto)) {
			return false;
		}
		super.setSaldo(getSaldo()-monto);
		return true;
	}

}
