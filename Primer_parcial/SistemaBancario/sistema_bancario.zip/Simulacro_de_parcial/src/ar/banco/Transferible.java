package ar.banco;

public interface Transferible {
	public Boolean depositar(Double monto);
	Boolean extraer(Double monto);
	Double getSaldo();

}
