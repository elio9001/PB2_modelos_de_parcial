package ar.banco;

public class Movimiento {
	private Integer idCuenta;
	private TipoOperacion tipoOperacion;
	private Double monto;
	public Movimiento(Integer idCuenta,TipoOperacion tipoOperacion, Double monto) {
		super();
		this.idCuenta = idCuenta;
		this.tipoOperacion = tipoOperacion;
		this.monto = monto;
	}
	public TipoOperacion getTipoOperacion() {
		return tipoOperacion;
	}
	
	
}
