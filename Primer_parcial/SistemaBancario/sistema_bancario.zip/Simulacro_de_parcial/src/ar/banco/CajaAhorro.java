package ar.banco;

public class CajaAhorro extends Cuenta{
	private final Double COMISION=5.;
	public CajaAhorro(Integer id, String titular, Double saldo) {
		super(id,titular,saldo);
	}

	@Override
	public Boolean extraer(Double monto) {
		if (monto<=0 || monto+COMISION>getSaldo()) {
			return false;
		}
		Double montoMasComision = monto + COMISION;
		super.setSaldo(getSaldo()-montoMasComision);
		return true;
	}

	


}
