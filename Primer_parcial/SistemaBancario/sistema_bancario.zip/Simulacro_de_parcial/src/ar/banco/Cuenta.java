package ar.banco;

import java.util.Objects;

public abstract class Cuenta implements Transferible {
	private Integer idCuenta;
	private String titular;
	private Double saldo;

	public Cuenta(Integer idCuenta, String titular, Double saldo) {
		super();
		this.idCuenta = idCuenta;
		this.titular = titular;
		this.saldo = saldo;
	}
	
	@Override
	public Boolean depositar(Double monto) {
		if (monto <= 0) {
			return false;
		}
		this.saldo+=monto;
		return true;

	}
	@Override
	public Double getSaldo() {
		return this.saldo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idCuenta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		Cuenta other = (Cuenta) obj;
		return Objects.equals(idCuenta, other.idCuenta);
	}

	
	
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
	public void descontarSaldo(Double monto) {
		this.saldo-=monto;
	}
	public Integer getIdCuenta() {
		return this.idCuenta;
	}

	
}
