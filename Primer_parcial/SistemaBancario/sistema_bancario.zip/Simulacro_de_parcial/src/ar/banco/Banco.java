package ar.banco;

import java.util.ArrayList;
import java.util.HashSet;

public class Banco {
	private String nombre;
	private HashSet<Cuenta> cuentas;
	private ArrayList<Movimiento> movimientos;

	public Banco(String nombre) {
		this.cuentas = new HashSet<Cuenta>();
		this.movimientos = new ArrayList<Movimiento>();
		this.nombre = nombre;
	}

	public Boolean agregarCuenta(Cuenta cuenta) {
		return this.cuentas.add(cuenta);
	}

	public Boolean depositar(Integer idCuenta, Double monto) {
		Cuenta cuentaEncontrada = buscarCuenta(idCuenta);

		if (cuentaEncontrada != null) {
			cuentaEncontrada.depositar(monto);
			Movimiento nuevoMovimiento = new Movimiento(idCuenta, TipoOperacion.DEPOSITO, monto);
			this.movimientos.add(nuevoMovimiento);
			return true;
		}
		return false;
	}

	public Cuenta buscarCuenta(Integer idCuenta) {
		for (Cuenta cuenta : cuentas) {
			if (cuenta.getIdCuenta().equals(idCuenta)) {
				return cuenta;
			}
		}
		return null;
	}

	public Boolean extraer(Integer idCuenta, Double monto) {
		Cuenta cuentaEncontrada = buscarCuenta(idCuenta);
		if (cuentaEncontrada != null) {
			if (cuentaEncontrada.extraer(monto)) {
				Movimiento nuevoMovimiento = new Movimiento(idCuenta, TipoOperacion.EXTRACCION, monto);
				this.movimientos.add(nuevoMovimiento);
				return true;
			}
		}
		return false;
	}

	public Integer cantidadDeCuentas() {
		return this.cuentas.size();

	}

	public Integer cantidadDeMovimientos() {
		return this.movimientos.size();
	}

	public Boolean transferir(Integer idOrigen, Integer idDestino, Double monto) {
		if (monto<=0) {
			return false;
		}
		if (idDestino.equals(idOrigen)) {
			return false;
		}
		Cuenta cuentaOrigen = buscarCuenta(idOrigen);
		Cuenta cuentaDestino = buscarCuenta(idDestino);
		
		if (cuentaDestino==null || cuentaOrigen==null) {
			return false;
		}
		if (cuentaOrigen.extraer(monto)) {
			cuentaDestino.depositar(monto);
			Movimiento movimientoOrigen = new Movimiento(idOrigen, TipoOperacion.TRANSFERENCIA_ENVIADA, monto);
			Movimiento movimientoDestino = new Movimiento(idDestino, TipoOperacion.TRANSEFERENCIA_RECIBIDA, monto);
			this.movimientos.add(movimientoOrigen);
			this.movimientos.add(movimientoDestino);
			return true;
		}
		return false;
	}

	public ArrayList<Movimiento> getMovimientos() {
		return movimientos;
	}

}
