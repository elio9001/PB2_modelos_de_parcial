package ar.edu.eventos;

public enum TipoEvento {
	MASIVO,VIP,REGULAR;
}
