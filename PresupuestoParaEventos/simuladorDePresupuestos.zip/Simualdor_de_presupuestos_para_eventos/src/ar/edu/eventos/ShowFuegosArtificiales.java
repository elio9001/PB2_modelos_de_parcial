package ar.edu.eventos;

public class ShowFuegosArtificiales implements Servicio{
	private final Double PRECIO_FIJO = 250000.;
	@Override
	public Double obtenerCostoDelSericio(Evento evento) {
		cambiarATipoDeEventoVIP(evento);
		return PRECIO_FIJO;
	}
	public void cambiarATipoDeEventoVIP(Evento evento){
		evento.setTipoEvento(TipoEvento.VIP);
	}

}
