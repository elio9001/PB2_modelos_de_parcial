package ar.edu.eventos;

import java.util.HashSet;

public class Evento {
	private Double precioBase;
	private Integer cantidadDeInvitados;
	private Integer duracion;
	private Double superficie;
	private HashSet<Servicio> servicios;
	private TipoEvento tipoEvento;

	public Evento(Double precioBase, Integer cantidadDeInvitados, Integer duracion, Double superficie) {
		super();
		this.servicios = new HashSet<Servicio>();
		this.precioBase = precioBase;
		this.cantidadDeInvitados = cantidadDeInvitados;
		this.duracion = duracion;
		this.superficie = superficie;
		determinarTipoDeEvento();
	}

	private void determinarTipoDeEvento() {
		if (cantidadDeInvitados > 500 && superficie > 1000.)
			tipoEvento = TipoEvento.MASIVO;
		else {
			if (cantidadDeInvitados < 100 && precioBase > 1500000.) {
				tipoEvento = TipoEvento.VIP;
			} else {
				tipoEvento = TipoEvento.REGULAR;
			}

		}

	}

	public Boolean existeElServicio(Servicio servicio) {
		for (Servicio s : servicios) {
			if (s.getClass().equals(servicio.getClass()))
				return true;
		}
		return false;
	}

	public void agregarUnServicio(Servicio servicio) {
		if (servicio != null && !existeElServicio(servicio))
			this.servicios.add(servicio);
	}

	public Integer cantidadDeServicios() {
		return this.servicios.size();
	}

	public Double getPrecioBase() {
		return precioBase;
	}

	public void setPrecioBase(Double precioBase) {
		this.precioBase = precioBase;
	}

	public Integer getCantidadDeInvitados() {
		return cantidadDeInvitados;
	}

	public void setCantidadDeInvitados(Integer cantidadDeInvitados) {
		this.cantidadDeInvitados = cantidadDeInvitados;
	}

	public Integer getDuracion() {
		return duracion;
	}

	public void setDuracion(Integer duracion) {
		this.duracion = duracion;
	}

	public Double getSuperficie() {
		return superficie;
	}

	public void setSuperficie(Double superficie) {
		this.superficie = superficie;
	}

	public TipoEvento getTipoEvento() {
		return tipoEvento;
	}

	public Double costoDeLosServicios() {
		Double costoDeTodosLosServicios = 0.;
		for (Servicio servicio : servicios) {
			costoDeTodosLosServicios += servicio.obtenerCostoDelSericio(this);
		}
		return costoDeTodosLosServicios;
	}

	public void setTipoEvento(TipoEvento tipo) {
		this.tipoEvento = tipo;
		
	}

}
