package ar.edu.eventos;

public class BandaEnVivo implements Servicio {
	private final Double PRECIO_FIJO = 200000.;
	private Double refuerzoSonoro = 100000.;

	@Override
	public Double obtenerCostoDelSericio(Evento evento) {
		if (evento.getTipoEvento().equals(TipoEvento.MASIVO)) {
			return PRECIO_FIJO + refuerzoSonoro;
		}
		return PRECIO_FIJO;
	}

}
