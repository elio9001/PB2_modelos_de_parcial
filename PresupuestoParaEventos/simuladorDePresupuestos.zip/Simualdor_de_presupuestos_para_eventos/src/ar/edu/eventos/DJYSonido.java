package ar.edu.eventos;

public class DJYSonido implements Servicio{
	private final Double precioInstalacion = 50000.;
	private Double precioPorhora;
	public DJYSonido(Double precioXHora) {
		this.precioPorhora = precioXHora;
	}
	@Override
	public Double obtenerCostoDelSericio(Evento evento) {
		return precioInstalacion + (precioPorhora * evento.getDuracion());
	}
}
