package ar.edu.eventos;

public class EventoCorporativo extends Evento{
	public EventoCorporativo(Double precioBase, Integer cantidadDeInvitados, Integer duracion, Double superficie) {
		super(precioBase, cantidadDeInvitados, duracion, superficie);
		// TODO Auto-generated constructor stub
	}

}
