package ar.edu.eventos;

import java.util.ArrayList;

public class Agencia {
	ArrayList<Evento> eventos;

	public Agencia() {
		this.eventos = new ArrayList<Evento>();
	}

	public Boolean registrarUnEvento(Evento evento) {
		if (evento != null) {
			return this.eventos.add(evento);
		}
		return false;
	}
	public Integer cantidadDeEventosRegistrados() {
		return this.eventos.size();
	}

	public void agregarUnServicioAUnEvento(Evento evento, Servicio servicio) {
		Evento eventoEncontrado = buscarEvento(evento);
		if (eventoEncontrado != null) {
			eventoEncontrado.agregarUnServicio(servicio);
		}
	}
	

	private Evento buscarEvento(Evento evento) {
		for (Evento e : this.eventos) {
			if (e.equals(evento)) {
				return e;
			}
		}
		return null;
	}
	
	public Integer cantidadDeServiciosDeUnEvento(Evento evento) {
		return buscarEvento(evento).cantidadDeServicios();
	}
	public Double precioBaseDeUnEvento(Evento evento) {
		Evento eventoEncontrado =  buscarEvento(evento);
		if (eventoEncontrado!=null) {
			return eventoEncontrado.getPrecioBase();
		}
		return null;
	}
	public Double precioFinal(Evento evento) {
		Evento eventoEncontrado = buscarEvento(evento);
		Double costoFinal=0.;
		if (evento!=null) {
			costoFinal = eventoEncontrado.getPrecioBase() + evento.costoDeLosServicios();
		}
		return costoFinal;
	}

	public Double precioConDescuentoPorcentaje(Evento evento,Double descuento) {
		Double descuentoCalculado = (precioFinal(evento) * descuento) /100.;
		Double precioConDescuento= precioFinal(evento) - descuentoCalculado;
		return precioConDescuento;
	}

	public Double precioConDescuentoImporte(Evento evento, Double descuento) {
		return precioFinal(evento) - descuento;
	}

}
