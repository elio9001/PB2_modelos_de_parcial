package ar.edu.eventos;

public class EventoSocial extends Evento{
	private final Double RECARGO_FIJO = 50000.;
	public EventoSocial(Double precioBase, Integer cantidadDeInvitados, Integer duracion, Double superficie) {
		super(precioBase, cantidadDeInvitados, duracion, superficie);
		super.setPrecioBase(super.getPrecioBase()+RECARGO_FIJO);
	}
	
}
