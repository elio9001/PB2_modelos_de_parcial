package ar.edu.eventos;

public interface Servicio {
	public Double obtenerCostoDelSericio(Evento evento);
	
}
