package ar.edu.eventos;

public class Catering implements Servicio{
	private Double precio;
	
	public Catering(Double precio) {
		this.precio = precio;
	}

	@Override
	public Double obtenerCostoDelSericio(Evento evento) {
		return this.precio * evento.getCantidadDeInvitados();
	}

}
