package ar.edu.eventos;

public class DecoracionPremium implements Servicio {
	private Double precioDecoracion;
	private final Double COSTO_MAXIMO = 400000.;

	public DecoracionPremium(Double precioDecoracion) {
		this.precioDecoracion = precioDecoracion;
	}

	@Override
	public Double obtenerCostoDelSericio(Evento evento) {
		if (evento.getTipoEvento() != null) {
			if (evento.getTipoEvento().equals(TipoEvento.VIP)) {
				evento.setPrecioBase(evento.getPrecioBase() + 50000.);
			}
		}
		Double costoDelServicio = precioDecoracion * evento.getSuperficie();
		if (costoDelServicio > COSTO_MAXIMO) {
			return COSTO_MAXIMO;
		}
		return costoDelServicio;
	}

}
