package ar.edu.eventos;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestEventos {

	@Test
	public void seRegistraUnEventoCorrectamente() {
		Agencia agencia = new Agencia();
		Double precioBase = 3213.;
		Integer cantidadInvidatos = 30;
		Integer duracion = 20;
		Double superficie = 23.22;

		EventoCorporativo ec1 = new EventoCorporativo(precioBase, cantidadInvidatos, duracion, superficie);
		Boolean seRegistro = agencia.registrarUnEvento(ec1);

		assertTrue(seRegistro);

	}

	@Test
	public void seRegistraUnEventoSocialYSeAplicaUnRecargoFijo() {
		Agencia agencia = new Agencia();
		Double precioBase = 50000.;
		Integer cantidadInvidatos = 30;
		Integer duracion = 20;
		Double superficie = 23.22;

		EventoSocial es1 = new EventoSocial(precioBase, cantidadInvidatos, duracion, superficie);
		agencia.registrarUnEvento(es1);
		Double precioBaseObtenido = agencia.precioBaseDeUnEvento(es1);
		Double precioEsperado = 100000.;
		assertEquals(precioEsperado, precioBaseObtenido);
	}

	@Test
	public void noSePuedeAgregarElMismoServicioDosVeces() {
		Agencia agencia = new Agencia();
		Double precioBase = 3213.;
		Integer cantidadInvidatos = 30;
		Integer duracion = 20;
		Double superficie = 23.22;

		EventoCorporativo ec1 = new EventoCorporativo(precioBase, cantidadInvidatos, duracion, superficie);
		agencia.registrarUnEvento(ec1);

		Catering cate1 = new Catering(200.);
		Catering cate2 = new Catering(200.);
		agencia.agregarUnServicioAUnEvento(ec1, cate1);
		agencia.agregarUnServicioAUnEvento(ec1, cate2);

		Integer cantidadEsperada = 1;
		assertEquals(cantidadEsperada, agencia.cantidadDeServiciosDeUnEvento(ec1), 0.01);
	}

	@Test
	public void seRegistranTreServiciosAUnEventoCorrectamente() {
		Agencia agencia = new Agencia();
		Double precioBase = 3213.;
		Integer cantidadInvidatos = 30;
		Integer duracion = 20;
		Double superficie = 23.22;

		EventoCorporativo ec1 = new EventoCorporativo(precioBase, cantidadInvidatos, duracion, superficie);
		agencia.registrarUnEvento(ec1);

		Catering cate1 = new Catering(200.);
		DJYSonido dj1 = new DJYSonido(5000.);
		DecoracionPremium dp1 = new DecoracionPremium(8000.);

		agencia.agregarUnServicioAUnEvento(ec1, cate1);
		agencia.agregarUnServicioAUnEvento(ec1, dj1);
		agencia.agregarUnServicioAUnEvento(ec1, dp1);

		Integer cantidadEsperada = 3;
		assertEquals(cantidadEsperada, agencia.cantidadDeServiciosDeUnEvento(ec1), 0.01);

	}

	@Test
	public void seCalculaElPrecioFinalLuegoDeAgregarLosServicios() {
		Agencia agencia = new Agencia();
		Double precioBase = 2000000.;
		Integer cantidadInvidatos = 200;
		Integer duracion = 6;
		Double superficie = 500.;

		EventoCorporativo ec1 = new EventoCorporativo(precioBase, cantidadInvidatos, duracion, superficie);
		agencia.registrarUnEvento(ec1);

		Catering cate1 = new Catering(15000.);
		DJYSonido dj1 = new DJYSonido(20000.);
		DecoracionPremium dp1 = new DecoracionPremium(500.);
		
		agencia.agregarUnServicioAUnEvento(ec1, cate1);
		agencia.agregarUnServicioAUnEvento(ec1, dj1);
		agencia.agregarUnServicioAUnEvento(ec1, dp1);
		Double precioFinalObtenido = agencia.precioFinal(ec1);
		Double precioEsperado  = 5420000.;
		
		assertEquals(precioEsperado,precioFinalObtenido);
	}

	@Test
	public void aplicarDescuentoDelDiezPorcientoAElPrecioFinalDeUnEvento() {
		Agencia agencia = new Agencia();
		Double precioBase = 2000000.;
		Integer cantidadInvidatos = 200;
		Integer duracion = 6;
		Double superficie = 500.;

		EventoCorporativo ec1 = new EventoCorporativo(precioBase, cantidadInvidatos, duracion, superficie);
		agencia.registrarUnEvento(ec1);

		Catering cate1 = new Catering(15000.);
		DJYSonido dj1 = new DJYSonido(20000.);
		DecoracionPremium dp1 = new DecoracionPremium(500.);
		
		agencia.agregarUnServicioAUnEvento(ec1, cate1);
		agencia.agregarUnServicioAUnEvento(ec1, dj1);
		agencia.agregarUnServicioAUnEvento(ec1, dp1);
		Double precioFinalObtenido = agencia.precioConDescuentoPorcentaje(ec1,10.);
		Double precioEsperado  = 4878000.;
		
		assertEquals(precioEsperado,precioFinalObtenido);
	}
	
	@Test
	public void aplicarDescuentoInporteAlPrecioFinalDeUnEvento() {
		Agencia agencia = new Agencia();
		Double precioBase = 2000000.;
		Integer cantidadInvidatos = 200;
		Integer duracion = 6;
		Double superficie = 500.;

		EventoCorporativo ec1 = new EventoCorporativo(precioBase, cantidadInvidatos, duracion, superficie);
		agencia.registrarUnEvento(ec1);

		Catering cate1 = new Catering(15000.);
		DJYSonido dj1 = new DJYSonido(20000.);
		DecoracionPremium dp1 = new DecoracionPremium(500.);
		BandaEnVivo bev1 = new BandaEnVivo();
		
//		ShowFuegosArtificiales sfa1 = new ShowFuegosArtificiales();
//		agencia.agregarUnServicioAUnEvento(ec1, sfa1);
		
		agencia.agregarUnServicioAUnEvento(ec1, cate1);
		agencia.agregarUnServicioAUnEvento(ec1, dj1);
		agencia.agregarUnServicioAUnEvento(ec1, dp1);
		agencia.agregarUnServicioAUnEvento(ec1, bev1);
		
		Double precioFinalObtenido = agencia.precioConDescuentoImporte(ec1,300000.);
		Double precioEsperado  = 5320000.;
		
		assertEquals(precioEsperado,precioFinalObtenido);
	}

}
