package ar.cine;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCine {

	@Test
	public void queMePermitaObtenerElNumeroSala2D() {
		Sala sala;
		Integer numeroSala = 10;
		Sala2D sala2d = new Sala2D(numeroSala);
		
		assertEquals(10, sala2d.getNumeroDeSala(),0.01);
	}
	@Test
	public void queMePermitaObtenerElNumeroSala3D() {
		Sala sala;
		Integer numeroSala = 15;
		Sala3D sala3d = new Sala3D(numeroSala);
		
		assertEquals(15, sala3d.getNumeroDeSala(),0.01);
	}
	@Test
	public void queMePermitaObtenerInformacionSala2D() {
		Sala sala;
		Integer numeroSala = 10;
		Sala2D sala2d = new Sala2D(numeroSala);
		String infoEsperada = "sala 10 formato 2D";
		
		assertEquals(infoEsperada, sala2d.informacionSala());
		
	}
	
	@Test
	public void queMePermitaElPrecioSala3D() {
		Sala sala;
		Integer numeroSala = 10;
		Sala3D sala3d = new Sala3D(numeroSala);
		
		Double precioObtenido = sala3d.obtenerPrecioBoleteria(10000.);
		Double precioEsperado = 15000.;
		
		assertEquals(precioEsperado, precioObtenido);
		
	}

}
