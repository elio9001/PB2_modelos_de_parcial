package ar.cine;

public class Sala2D extends Sala{

	public Sala2D(Integer numSala) {
		super(numSala);
		
	}
	
	public String informacionSala() {
		return super.informacionSala() + " formato 2D";
	}

	@Override
	public Double obtenerPrecioBoleteria(Double precioBase) {
		return precioBase;
	}
	
	

}
