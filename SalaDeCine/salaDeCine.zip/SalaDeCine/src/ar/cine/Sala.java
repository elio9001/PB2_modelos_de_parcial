package ar.cine;

public abstract class Sala {
	private Integer numeroDeSala;
	public Sala(Integer numSala) {
		this.numeroDeSala = numSala;
	}
	public Integer getNumeroDeSala() {
		return numeroDeSala;
	}
	
	public String informacionSala() {
		return "sala " + numeroDeSala;
	}
	
	public abstract Double obtenerPrecioBoleteria(Double precio);
	
}
