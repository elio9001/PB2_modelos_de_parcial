package ar.cine;

public class Sala3D extends Sala{
	final Double precioLentes = 5000.;
	public Sala3D(Integer numSala) {
		super(numSala);
		
	}

	@Override
	public Double obtenerPrecioBoleteria(Double precio) {
		
		return precio+this.precioLentes;
	}

}
